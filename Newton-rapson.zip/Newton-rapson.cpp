#include <iostream>
#include<cmath>
#include<cstdlib>
int main()
{
    //Definición de variables
    double funcion, derivada, x, x0;
    double euler=exp(1.0);
    int iteraciones=100000;
    system("cls");
    std::cout<<"Ingrese el valor aproximado en el cual cree que esta la raiz de la función: "<<std::endl;
    std::cin>>x0;
    //Metodo Newton-Raphson
    for(int i=0; i < iteraciones; i++)
    {
    funcion=pow(euler , 2*x0)+log(2*x0);
    derivada=pow(euler , 2*x0)*2+1/x0;
    x=x0-funcion/derivada;
    x0=x;
    }
//Resultado obtenido
std::cout<<"La raiz de la función es: "<< x <<std::endl;

    return 0;

}